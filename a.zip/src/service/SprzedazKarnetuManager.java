package service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import main.SprzedazKarnetu;

public class SprzedazKarnetuManager {
	private static Connection connection;
	private String url = "jdbc:hsqldb:hsql://localhost/";
	private String createTableSprzedazKarnetu = "CREATE TABLE SprzedazKarnetu(id_klient int foreign key references Klient(id_klient), id_karnet int foreign key references Karnet(id_karnet))";
	
	
	private static PreparedStatement DodajSprzedazKarnetu;
	private static PreparedStatement UsunSprzedazKarnetu;
	private static PreparedStatement usunSprzedazeKarnetu;
	private static PreparedStatement PobierzSprzedazeKarnetu;
	private static PreparedStatement EdytujSprzedazKarnetu;
	
	private Statement statement;
	
	public SprzedazKarnetuManager(){
		try{
			connection = DriverManager.getConnection(url);
			statement = connection.createStatement();
			
			ResultSet rs =	connection.getMetaData().getTables(null, null, null, null);
			boolean tableExists = false;
			while(rs.next()){
				if("SprzedazKarnetu".equalsIgnoreCase(rs.getString("TABLE_NAME"))){
					tableExists = true;
					break;
				}
			}
			
			if(!tableExists)
				statement.executeUpdate(createTableSprzedazKarnetu);
			
			DodajSprzedazKarnetu = connection.prepareStatement("INSERT INTO SprzedazKarnetu(id_klient, id_karnet) VALUES (?, ?)");
			UsunSprzedazKarnetu = connection.prepareStatement("DELETE FROM SprzedazKarnetu WHERE id_klient = ? and id_karnet");
			usunSprzedazeKarnetu = connection.prepareStatement("DELETE FROM SprzedazKarnetu");
			PobierzSprzedazeKarnetu = connection.prepareStatement("SELECT id_klient, id_karnet FROM SprzedazKarnetu");
			EdytujSprzedazKarnetu = connection.prepareStatement("UPDATE SprzedazKarnetu SET id_karnet = ? WHERE id_klient = ?");
			
				
			
	}catch(SQLException e){
		e.printStackTrace();
	}
}

public static Connection getConnection(){
	return connection;
}

	public static void wyczyscSprzedazeKarnetu(){
	try{
		usunSprzedazeKarnetu.executeUpdate();
		} catch (SQLException e){ 
			e.printStackTrace();
		}
}

	public int dodajSprzedazKarnetu(SprzedazKarnetu s){
		int count = 0;
		try{
			DodajSprzedazKarnetu.setInt(1, s.getId_klient());
			DodajSprzedazKarnetu.setInt(2, s.getId_karnet());

			
			
			
			count = DodajSprzedazKarnetu.executeUpdate();
			
			
		}catch (SQLException e){
			e.printStackTrace();
		}
		return count;
	}
	
	public int edytujSprzedazKarnetu(SprzedazKarnetu s){
		int count = 0;
		try{
		
			
			EdytujSprzedazKarnetu.setInt(1, s.getId_karnet());
		
			EdytujSprzedazKarnetu.setInt(2, s.getId_klient());
			
			
			count = EdytujSprzedazKarnetu.executeUpdate();
			
			
		}catch (SQLException e){
			e.printStackTrace();
		}
		return count;
	}
	public int usunSprzedazKarnetu(SprzedazKarnetu s){
		int count = 0;
		try{
			UsunSprzedazKarnetu.setInt(1, s.getId_klient());
			UsunSprzedazKarnetu.setInt(2, s.getId_karnet());
			count = UsunSprzedazKarnetu.executeUpdate();
			
			
		}catch (SQLException e){
			e.printStackTrace();
		}
		return count;
	}
	
	
	public List<SprzedazKarnetu> SprzedazKarnetu(){
		List<SprzedazKarnetu> sprzedazeKarnetu = new ArrayList<SprzedazKarnetu>();
		
		try{
			ResultSet rs = PobierzSprzedazeKarnetu.executeQuery();
			
			while (rs.next()){
				SprzedazKarnetu s = new SprzedazKarnetu();
				s.setId_klient(rs.getInt("id_klient"));
				s.setId_karnet(rs.getInt("id_karnet"));
				sprzedazeKarnetu.add(s);
			}}
			catch(SQLException e) {
				e.printStackTrace();
			}
			return sprzedazeKarnetu;
		}
	}